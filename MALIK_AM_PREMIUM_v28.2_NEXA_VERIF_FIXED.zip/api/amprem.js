// Vercel serverless function - NEXA AM Verification
const { getIp, rateLimit, hasValidGate, readBody } = require("./_lib");
const { readSession } = require("./_auth");

const BASE = "https://api.nexadev.my.id";
const str = v => typeof v === "string" && v.trim().length > 0;
const fail = (res, code, message) => res.status(code).json({ success:false, message });

async function nexaverif(email, link, key){
  const url = `${BASE}/am/verif/?key=${encodeURIComponent(key)}&email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}`;
  const r = await fetch(url, { method:"GET" });
  const text = await r.text();
  try {
    return JSON.parse(text);
  } catch(e) {
    return { success:false, message:"Response API NEXA bukan JSON", raw:text.slice(0,200) };
  }
}

module.exports = async (req,res)=>{
  res.setHeader("Cache-Control","no-store");
  if(req.method!=="POST") return fail(res,405,"Method not allowed");

  if(process.env.REQUIRE_LOGIN==="true" && !readSession(req))
    return fail(res,401,"Silakan login terlebih dahulu.");

  const key = process.env.NEXA_API_KEY || process.env.AXZYE_API_KEY;
  if(!key) return fail(res,500,"Server belum dikonfigurasi (NEXA_API_KEY kosong)");

  try{
    const {action,email,rawLink} = readBody(req);
    const ip=getIp(req);

    if(!str(email) || !/^\S+@\S+\.\S+$/.test(email.trim()))
      return fail(res,400,"Email tidak valid");

    const em=email.trim().toLowerCase();

    if(action==="send"){
      return fail(res,400,"Gunakan link verifikasi dari email Alight Motion.");
    }

    if(action==="verify"){
      if(!str(rawLink)) return fail(res,400,"Link verifikasi kosong");

      if(!(await rateLimit("verify-ip:"+ip,10,600)))
        return fail(res,429,"Terlalu banyak percobaan.");

      return res.status(200).json(await nexaverif(em,rawLink,key));
    }

    return fail(res,400,"invalid action");
  }catch(e){
    return fail(res,500,e.message);
  }
};
