// GET /api/health -> { online: boolean }  (upstream dianggap online jika merespons HTTP apa pun)
const BASE = "https://api.nexadev.my.id";

module.exports = async (req, res) => {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  let online = false;
  try {
    await fetch(BASE, { method: "GET", signal: ctrl.signal });
    online = true;
  } catch (e) {
    online = false;
  } finally {
    clearTimeout(timer);
  }
  res.setHeader("Cache-Control", "s-maxage=30, stale-while-revalidate=60");
  return res.status(200).json({ online });
};
