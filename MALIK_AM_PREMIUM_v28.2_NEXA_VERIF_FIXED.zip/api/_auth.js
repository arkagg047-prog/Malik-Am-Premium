// Helper login (awalan "_" = bukan endpoint). Tanpa framework: crypto bawaan Node + Upstash Redis REST.
// Env: SESSION_SECRET (acak, min 32 karakter), UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN,
//      SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS + MAIL_FROM (verifikasi email saat daftar)
const crypto = require("crypto");

const COOKIE = "am_session";
const MAX_AGE = 60 * 60 * 24 * 30; // 30 hari

const secret = () => process.env.SESSION_SECRET;
const isConfigured = () =>
  !!(secret() && process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN);

const isMailConfigured = () =>
  !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS && process.env.MAIL_FROM);

let _transport = null;
function transport() {
  if (_transport) return _transport;
  const nodemailer = require("nodemailer");
  const port = parseInt(process.env.SMTP_PORT || "465", 10);
  _transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: port === 465, // 465 = SSL, 587 = STARTTLS
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    connectionTimeout: 10000, greetingTimeout: 10000, socketTimeout: 15000
  });
  return _transport;
}

/* ---------- storage (Upstash REST) ---------- */
async function redis(cmd) {
  const url = process.env.UPSTASH_REDIS_REST_URL, token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) throw new Error("Penyimpanan akun belum dikonfigurasi");
  const r = await fetch(url, {
    method: "POST",
    headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
    body: JSON.stringify(cmd)
  });
  const d = await r.json();
  if (d && d.error) throw new Error("Penyimpanan akun error");
  return d.result;
}

/* ---------- password (scrypt + salt acak) ---------- */
const scrypt = (pw, salt) =>
  new Promise((ok, no) => crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => (e ? no(e) : ok(k))));

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt);
  return salt.toString("hex") + ":" + key.toString("hex");
}

async function verifyPassword(pw, stored) {
  const [s, h] = String(stored || "").split(":");
  const key = await scrypt(pw, Buffer.from(s || "00", "hex"));
  const hb = Buffer.from(h || "", "hex");
  return hb.length === key.length && crypto.timingSafeEqual(hb, key);
}

/* ---------- sesi: cookie HttpOnly bertanda tangan HMAC ---------- */
const sign = data => crypto.createHmac("sha256", secret()).update(data).digest("base64url");

function makeSession(email) {
  const p = Buffer.from(JSON.stringify({ e: email, exp: Date.now() + MAX_AGE * 1000 })).toString("base64url");
  return p + "." + sign(p);
}

function readSession(req) {
  if (!secret()) return null;
  const raw = String(req.headers.cookie || "").split(/;\s*/).find(c => c.startsWith(COOKIE + "="));
  if (!raw) return null;
  const [p, sig] = decodeURIComponent(raw.slice(COOKIE.length + 1)).split(".");
  if (!p || !sig) return null;
  const a = Buffer.from(sig), b = Buffer.from(sign(p));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const d = JSON.parse(Buffer.from(p, "base64url").toString());
    return d.e && d.exp > Date.now() ? { email: d.e } : null;
  } catch (e) { return null; }
}

const sessionCookie = email =>
  `${COOKIE}=${encodeURIComponent(makeSession(email))}; Path=/; Max-Age=${MAX_AGE}; HttpOnly; Secure; SameSite=Lax`;
const clearCookie = () => `${COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`;

/* ---------- kode verifikasi email (6 digit) ---------- */
const newCode = () => String(crypto.randomInt(0, 1000000)).padStart(6, "0");
const codeHash = (email, code) => sign("verify:" + email + ":" + code);
function codeMatches(email, code, stored) {
  const a = Buffer.from(codeHash(email, String(code))), b = Buffer.from(String(stored || ""));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function sendVerificationMail(to, code) {
  const text = `Kode verifikasi MALIK AM PREMIUM kamu: ${code}\n\nBerlaku 10 menit. Abaikan email ini jika kamu tidak mendaftar.`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:420px;margin:0 auto;padding:24px;background:#050505;color:#fff">
<p style="font-weight:800;letter-spacing:.5px;margin:0 0 16px">MALIK AM PREMIUM</p>
<p style="margin:0 0 12px">Kode verifikasi kamu:</p>
<p style="font-size:34px;font-weight:900;letter-spacing:8px;margin:0 0 16px;padding:14px;background:#22C55E;color:#050505;border:3px solid #000;text-align:center">${code}</p>
<p style="color:#A1A1AA;font-size:13px;margin:0">Berlaku 10 menit. Abaikan email ini jika kamu tidak mendaftar.</p></div>`;
  try {
    await transport().sendMail({ from: process.env.MAIL_FROM, to, subject: "Kode verifikasi MALIK AM PREMIUM", text, html });
  } catch (e) {
    console.error("smtp error:", e && e.message);
    throw new Error("mail");
  }
}

module.exports = { isMailConfigured, newCode, codeHash, codeMatches, sendVerificationMail, isConfigured, redis, hashPassword, verifyPassword, readSession, sessionCookie, clearCookie };
