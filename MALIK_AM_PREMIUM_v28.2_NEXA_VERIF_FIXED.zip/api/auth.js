// Vercel serverless function: sistem login email + password dengan verifikasi email.
// GET  /api/auth                                  -> { configured, authenticated, email }
// POST /api/auth {action:"register", email, password}  -> kirim kode 6 digit ke email (akun belum dibuat)
// POST /api/auth {action:"verify", email, code}        -> kode benar: akun dibuat + login
// POST /api/auth {action:"resend", email}              -> kirim ulang kode
// POST /api/auth {action:"login", email, password} | {action:"logout"}
// Env wajib: SESSION_SECRET, UPSTASH_REDIS_REST_URL, UPSTASH_REDIS_REST_TOKEN, SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, MAIL_FROM
const { getIp, rateLimit, readBody } = require("./_lib");
const A = require("./_auth");

const EMAIL_RE = /^\S+@\S+\.\S+$/;
const PENDING_TTL = 600; // 10 menit
const MAX_TRIES = 5;
const out = (res, code, body) => res.status(code).json(body);
const fail = (res, code, message) => out(res, code, { success: false, message });
const userKey = em => "user:" + em;
const pendKey = em => "pending:" + em;
const parse = raw => { try { return raw ? JSON.parse(raw) : null; } catch (e) { return null; } };

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");

  if (req.method === "GET") {
    if (!A.isConfigured()) return out(res, 200, { configured: false, authenticated: false });
    const s = A.readSession(req);
    return out(res, 200, { configured: true, authenticated: !!s, email: s ? s.email : null });
  }
  if (req.method !== "POST") return fail(res, 405, "Method not allowed");
  if (!A.isConfigured()) return fail(res, 503, "Sistem login belum dikonfigurasi (SESSION_SECRET / Upstash).");

  try {
    const { action, email, password, code } = readBody(req);
    const ip = getIp(req);

    if (action === "logout") {
      res.setHeader("Set-Cookie", A.clearCookie());
      return out(res, 200, { success: true });
    }
    if (!["register", "verify", "resend", "login"].includes(action)) return fail(res, 400, "invalid action");
    if (typeof email !== "string" || email.length > 254 || !EMAIL_RE.test(email.trim())) return fail(res, 400, "Email tidak valid");
    const em = email.trim().toLowerCase();

    /* ----- daftar: simpan data sementara + kirim kode ----- */
    if (action === "register") {
      if (typeof password !== "string" || password.length < 8 || password.length > 128)
        return fail(res, 400, "Password minimal 8 karakter");
      if (!A.isMailConfigured()) return fail(res, 503, "Verifikasi email belum dikonfigurasi (SMTP_HOST / SMTP_USER / SMTP_PASS / MAIL_FROM).");
      if (!(await rateLimit("reg-ip:" + ip, 5, 3600)) || !(await rateLimit("send-code-em:" + em, 3, 600)))
        return fail(res, 429, "Terlalu banyak permintaan. Coba lagi nanti.");
      if (await A.redis(["GET", userKey(em)])) return fail(res, 409, "Email sudah terdaftar. Silakan masuk.");

      const c = A.newCode();
      const rec = JSON.stringify({ hash: await A.hashPassword(password), codeHash: A.codeHash(em, c), attempts: 0 });
      await A.redis(["SET", pendKey(em), rec, "EX", PENDING_TTL]);
      try { await A.sendVerificationMail(em, c); }
      catch (e) {
        await A.redis(["DEL", pendKey(em)]);
        return fail(res, 502, "Gagal mengirim email verifikasi. Periksa alamat email lalu coba lagi.");
      }
      return out(res, 200, { success: true, pending: true, email: em });
    }

    /* ----- kirim ulang kode ----- */
    if (action === "resend") {
      if (!(await rateLimit("resend-ip:" + ip, 10, 600)) || !(await rateLimit("send-code-em:" + em, 3, 600)))
        return fail(res, 429, "Terlalu sering meminta kode. Tunggu beberapa menit.");
      const rec = parse(await A.redis(["GET", pendKey(em)]));
      if (!rec) return fail(res, 400, "Sesi pendaftaran kedaluwarsa. Silakan daftar ulang.");
      const c = A.newCode();
      rec.codeHash = A.codeHash(em, c); rec.attempts = 0;
      await A.redis(["SET", pendKey(em), JSON.stringify(rec), "EX", PENDING_TTL]);
      try { await A.sendVerificationMail(em, c); }
      catch (e) { return fail(res, 502, "Gagal mengirim email verifikasi. Coba lagi."); }
      return out(res, 200, { success: true, pending: true, email: em });
    }

    /* ----- verifikasi kode: buat akun + login ----- */
    if (action === "verify") {
      if (typeof code !== "string" || !/^\d{6}$/.test(code.trim())) return fail(res, 400, "Kode harus 6 digit angka");
      if (!(await rateLimit("verify-code-ip:" + ip, 20, 600))) return fail(res, 429, "Terlalu banyak percobaan. Tunggu beberapa menit.");
      const rec = parse(await A.redis(["GET", pendKey(em)]));
      if (!rec) return fail(res, 400, "Kode kedaluwarsa. Silakan daftar ulang.");
      if (!A.codeMatches(em, code.trim(), rec.codeHash)) {
        rec.attempts = (rec.attempts || 0) + 1;
        if (rec.attempts >= MAX_TRIES) {
          await A.redis(["DEL", pendKey(em)]);
          return fail(res, 429, "Terlalu banyak kode salah. Silakan daftar ulang.");
        }
        await A.redis(["SET", pendKey(em), JSON.stringify(rec), "EX", PENDING_TTL]);
        return fail(res, 400, `Kode salah. Sisa percobaan: ${MAX_TRIES - rec.attempts}`);
      }
      const user = JSON.stringify({ email: em, hash: rec.hash, createdAt: Date.now(), verified: true });
      const ok = await A.redis(["SET", userKey(em), user, "NX"]);
      await A.redis(["DEL", pendKey(em)]);
      if (ok !== "OK") return fail(res, 409, "Email sudah terdaftar. Silakan masuk.");
      res.setHeader("Set-Cookie", A.sessionCookie(em));
      return out(res, 200, { success: true, email: em });
    }

    /* ----- login ----- */
    if (typeof password !== "string" || password.length < 8 || password.length > 128)
      return fail(res, 400, "Password minimal 8 karakter");
    if (!(await rateLimit("login-ip:" + ip, 10, 600)) || !(await rateLimit("login-em:" + em, 5, 600)))
      return fail(res, 429, "Terlalu banyak percobaan masuk. Tunggu beberapa menit.");
    const user = parse(await A.redis(["GET", userKey(em)]));
    const valid = await A.verifyPassword(password, user && user.hash); // tetap hitung hash agar waktu respons seragam
    if (!user || !valid) return fail(res, 401, "Email atau password salah");
    res.setHeader("Set-Cookie", A.sessionCookie(em));
    return out(res, 200, { success: true, email: em });
  } catch (e) {
    return fail(res, 500, "Terjadi kesalahan server. Coba lagi.");
  }
};
