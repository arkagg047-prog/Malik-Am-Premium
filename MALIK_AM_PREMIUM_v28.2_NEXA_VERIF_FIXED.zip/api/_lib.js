// Helper bersama (awalan "_" = tidak dideploy sebagai endpoint oleh Vercel)
const crypto = require("crypto");

const COOKIE = "am_gate";
const MAX_AGE = 60 * 60 * 24 * 30; // 30 hari

const getIp = req =>
  String((req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "unknown")).split(",")[0].trim();

/* ---------- rate limit ----------
   Pakai Upstash Redis bila UPSTASH_REDIS_REST_URL & _TOKEN diisi (akurat lintas instance).
   Kalau tidak, fallback ke memori instance (best-effort saja, reset saat cold start). */
const mem = new Map();

async function rateLimit(key, limit, windowSec) {
  const url = process.env.UPSTASH_REDIS_REST_URL, token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (url && token) {
    try {
      const r = await fetch(url + "/pipeline", {
        method: "POST",
        headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
        body: JSON.stringify([["INCR", key], ["EXPIRE", key, windowSec, "NX"]])
      });
      const d = await r.json();
      const n = Number(d && d[0] && d[0].result);
      if (Number.isFinite(n)) return n <= limit;
    } catch (e) { /* gagal hubungi Redis: jangan blokir pengguna */ }
    return true;
  }
  const now = Date.now();
  if (mem.size > 5000) for (const [k, v] of mem) if (v.exp < now) mem.delete(k);
  let e = mem.get(key);
  if (!e || e.exp < now) e = { n: 0, exp: now + windowSec * 1000 };
  e.n++; mem.set(key, e);
  return e.n <= limit;
}

/* ---------- premium access gate ---------- */
function hasValidGate(req) {
  return true;
}

const cookieHeader = () =>
  `${COOKIE}=${encodeURIComponent(makeToken())}; Path=/; Max-Age=${MAX_AGE}; HttpOnly; Secure; SameSite=Lax`;

const readBody = req => {
  try { return typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {}); }
  catch (e) { return {}; }
};

module.exports = { getIp, rateLimit, hasValidGate, cookieHeader, readBody };
