# MALIK AM PREM FREE

Versi production MALIK AM Premium. Sistem follow channel sudah dihapus.

Alur:
1. Masukkan email Alight Motion.
2. Kirim magic link.
3. Verifikasi link.
4. Aktivasi premium.


Premium Experience V6 Final Polish applied.


V10 QA: final cleanup; activation flow kept.


Release V12: final polish preparation.


## Release V13 Production Audit
- Final cleanup stage.
- Follow channel system remains removed.

## Release V27 — Cyber Neobrutalist Premium UI
- Interface only: `css/style.css`, `index.html`, `pages/*.html`, `assets/am-logo.svg`, new `js/ui.js` (scroll reveal + logout).
- Activation flow, `/api/*`, env vars (`AXZYE_API_KEY`, Upstash) and `js/app.js` logic untouched
  (only addition in app.js: one line that fills the account email in the dashboard card).

## Release V28 — Login email + password
Endpoint baru `api/auth.js` (+ helper `api/_auth.js`), klien `js/auth.js`. Tanpa framework tambahan.
- Akun disimpan di Upstash Redis (password di-hash scrypt + salt), sesi = cookie HttpOnly bertanda tangan HMAC (30 hari).
- Env baru (Vercel → Settings → Environment Variables):
  - `SESSION_SECRET` — string acak minimal 32 karakter (wajib agar login aktif)
  - `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN` — wajib untuk menyimpan akun (sudah dipakai juga untuk rate limit)
  - `REQUIRE_LOGIN=true` — opsional; bila diisi, `/api/amprem` menolak request tanpa sesi login
- Jika `SESSION_SECRET`/Upstash belum diisi, login otomatis nonaktif dan aplikasi berjalan seperti sebelumnya.
- Logout (Settings) mengakhiri sesi server dan menghapus riwayat lokal perangkat.

### V28.2 — Verifikasi email via SMTP (nodemailer)
- Kode 6 digit dikirim lewat SMTP (bukan Resend lagi). Berlaku 10 menit, maks 5 kali salah.
- Env: `SMTP_HOST`, `SMTP_PORT` (465 SSL / 587 STARTTLS), `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM` (contoh `MALIK AM PREMIUM <emailkamu@gmail.com>`).
- Gmail: aktifkan verifikasi 2 langkah, buat App Password, pakai `smtp.gmail.com` port 465.
- Brevo: `smtp-relay.brevo.com` port 587, user/pass dari menu SMTP & API.
- Jika SMTP kosong, pendaftaran ditolak dengan pesan jelas (login akun lama tetap jalan).

## Deploy ke Vercel
1. Upload folder ini ke GitHub, lalu Vercel -> Add New -> Project -> Import.
2. Framework Preset: Other. Build/Output kosongkan.
3. Isi semua env (lihat `.env.example`), lalu Deploy / Redeploy.
4. Cek `/api/health`.
