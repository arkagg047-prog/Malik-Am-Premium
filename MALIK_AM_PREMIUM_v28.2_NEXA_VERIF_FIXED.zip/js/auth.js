/* Login client (UI + panggilan /api/auth). Tidak menyentuh alur aktivasi di app.js. */
(function(){
  var d=document,root=d.documentElement;
  var base=/\/pages\//.test(location.pathname)?'../':'';
  var gate=d.getElementById('authGate');
  var EMAIL_RE=/^\S+@\S+\.\S+$/;

  function post(action,data){
    var body={action:action};for(var k in data)body[k]=data[k];
    return fetch('/api/auth',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)})
      .then(function(r){return r.json()});
  }
  var A=window.AMAuth={user:null,configured:false,api:post};

  function openGate(){
    if(!gate)return;
    gate.hidden=false;d.body.classList.add('auth-locked');
    var f=d.getElementById('authEmail');if(f)setTimeout(function(){f.focus({preventScroll:true})},350);
  }
  function closeGate(){
    if(!gate)return;
    gate.hidden=true;d.body.classList.remove('auth-locked');
  }

  A.ready=fetch('/api/auth',{cache:'no-store',credentials:'same-origin'})
    .then(function(r){return r.json()})
    .catch(function(){return {configured:false}})
    .then(function(s){
      A.configured=!!(s&&s.configured);
      A.user=s&&s.authenticated?s.email:null;
      if(A.configured&&!A.user){
        if(gate)openGate();else location.replace(base+'index.html');
      }
      return A;
    })
    .then(function(a){root.classList.remove('auth-wait');return a;});

  if(!gate)return;

  /* ---------- form masuk / daftar ---------- */
  var mode='login';
  var form=d.getElementById('authForm'),
      tabs=gate.querySelectorAll('[data-auth-tab]'),
      email=d.getElementById('authEmail'),
      pw=d.getElementById('authPassword'),
      pw2=d.getElementById('authPassword2'),
      confirmRow=d.getElementById('authConfirmRow'),
      btn=d.getElementById('authSubmit'),
      msg=d.getElementById('authMsg'),
      title=d.getElementById('authTitle'),
      sub=d.getElementById('authSub'),
      eye=d.getElementById('authEye');
  var LABEL={login:'Masuk',register:'Buat akun'};

  function say(t){msg.textContent=t||'';msg.hidden=!t;if(t){msg.style.animation='none';msg.offsetHeight;msg.style.animation='';}}
  function setMode(m){
    mode=m;
    tabs.forEach(function(t){var on=t.dataset.authTab===m;t.classList.toggle('on',on);t.setAttribute('aria-selected',on)});
    confirmRow.hidden=m!=='register';
    pw.autocomplete=m==='register'?'new-password':'current-password';
    btn.textContent=LABEL[m];
    title.textContent=m==='register'?'Create your account':'Welcome back';
    sub.textContent=m==='register'?'Daftar sekali, lalu masuk kapan saja.':'Masuk untuk mengaktifkan premium.';
    say('');
  }
  tabs.forEach(function(t){t.addEventListener('click',function(){setMode(t.dataset.authTab)})});
  eye.addEventListener('click',function(){
    var show=pw.type==='password';
    pw.type=show?'text':'password';if(pw2)pw2.type=pw.type;
    eye.textContent=show?'Sembunyi':'Lihat';
  });

  /* ---------- panel verifikasi kode email ---------- */
  var vForm=d.getElementById('authVerify'),head=d.getElementById('authHead'),
      vCode=d.getElementById('authCode'),vBtn=d.getElementById('authVerifyBtn'),
      vMsg=d.getElementById('authVerifyMsg'),vEmail=d.getElementById('authVerifyEmail'),
      vResend=d.getElementById('authResend'),vBack=d.getElementById('authBack');
  var pendingEmail='',pendingPw='',resendTimer=null;

  function vSay(t){vMsg.textContent=t||'';vMsg.hidden=!t;if(t){vMsg.style.animation='none';vMsg.offsetHeight;vMsg.style.animation='';}}
  function cooldown(sec){
    clearInterval(resendTimer);vResend.disabled=true;
    var left=sec;
    (function tick(){
      vResend.textContent=left>0?'Kirim ulang ('+left+'s)':'Kirim ulang kode';
      if(left<=0){vResend.disabled=false;clearInterval(resendTimer);}
      left--;
    })();
    resendTimer=setInterval(function(){
      vResend.textContent=left>0?'Kirim ulang ('+left+'s)':'Kirim ulang kode';
      if(left<=0){vResend.disabled=false;clearInterval(resendTimer);}
      left--;
    },1000);
  }
  function showVerify(em){
    pendingEmail=em;vEmail.textContent=em;vCode.value='';vSay('');
    head.hidden=true;form.hidden=true;vForm.hidden=false;
    cooldown(45);setTimeout(function(){vCode.focus({preventScroll:true})},200);
  }
  function hideVerify(){
    clearInterval(resendTimer);vForm.hidden=true;head.hidden=false;form.hidden=false;pendingPw='';
  }
  function finish(em){
    A.user=em;pw.value='';pw2.value='';vCode.value='';pendingPw='';
    hideVerify();closeGate();
    d.dispatchEvent(new CustomEvent('amauth',{detail:{email:A.user}}));
  }

  /* ---------- submit masuk / daftar ---------- */
  form.addEventListener('submit',function(e){
    e.preventDefault();
    var em=email.value.trim(),p=pw.value;
    if(!EMAIL_RE.test(em))return say('Masukkan email yang valid.');
    if(p.length<8)return say('Password minimal 8 karakter.');
    if(mode==='register'&&p!==pw2.value)return say('Konfirmasi password tidak sama.');
    say('');btn.disabled=true;btn.textContent='Memproses…';
    post(mode,{email:em,password:p}).then(function(r){
      if(r&&r.success&&r.pending)showVerify(r.email||em);
      else if(r&&r.success)finish(r.email||em);
      else say((r&&r.message)||'Gagal. Coba lagi.');
    }).catch(function(){say('Tidak bisa terhubung ke server. Coba lagi.');})
      .then(function(){btn.disabled=false;btn.textContent=LABEL[mode];});
  });

  /* ---------- submit kode ---------- */
  vCode.addEventListener('input',function(){vCode.value=vCode.value.replace(/\D/g,'').slice(0,6);});
  vForm.addEventListener('submit',function(e){
    e.preventDefault();
    var c=vCode.value.trim();
    if(!/^\d{6}$/.test(c))return vSay('Masukkan kode 6 digit.');
    vSay('');vBtn.disabled=true;vBtn.textContent='Memverifikasi…';
    post('verify',{email:pendingEmail,code:c}).then(function(r){
      if(r&&r.success)finish(r.email||pendingEmail);
      else vSay((r&&r.message)||'Kode salah. Coba lagi.');
    }).catch(function(){vSay('Tidak bisa terhubung ke server. Coba lagi.');})
      .then(function(){vBtn.disabled=false;vBtn.innerHTML='Verifikasi &amp; buat akun';});
  });
  vResend.addEventListener('click',function(){
    if(vResend.disabled)return;
    vSay('');vResend.disabled=true;vResend.textContent='Mengirim…';
    post('resend',{email:pendingEmail}).then(function(r){
      if(r&&r.success){vSay('');cooldown(45);vCode.value='';vCode.focus({preventScroll:true});}
      else{vSay((r&&r.message)||'Gagal mengirim ulang.');vResend.disabled=false;vResend.textContent='Kirim ulang kode';}
    }).catch(function(){vSay('Tidak bisa terhubung ke server.');vResend.disabled=false;vResend.textContent='Kirim ulang kode';});
  });
  vBack.addEventListener('click',function(){hideVerify();setMode('register');email.focus({preventScroll:true});});
  setMode('login');
})();
