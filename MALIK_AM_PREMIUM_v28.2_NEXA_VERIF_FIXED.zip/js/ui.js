/* UI-only helpers: scroll reveal + logout. No activation/API logic here. */
(function(){
  var d=document,root=d.documentElement;
  var calm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  root.classList.add('js');

  var els=[].slice.call(d.querySelectorAll('[data-reveal]'));
  if(calm||!('IntersectionObserver' in window)){
    els.forEach(function(e){e.classList.add('in');});
  }else{
    var io=new IntersectionObserver(function(list){
      list.forEach(function(x){
        if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target);}
      });
    },{rootMargin:'0px 0px -6% 0px',threshold:.05});
    els.forEach(function(e){io.observe(e);});
  }

  /* Logout: akhiri sesi server (jika login aktif), hapus data lokal perangkat, lalu kembali ke Home */
  d.addEventListener('click',function(e){
    var b=e.target.closest&&e.target.closest('[data-logout]');
    if(!b)return;
    if(!confirm('Logout dari perangkat ini? Riwayat order lokal akan dihapus.'))return;
    try{localStorage.removeItem('history');localStorage.removeItem('sendUntil');}catch(err){}
    var go=function(){location.href=b.getAttribute('data-logout');};
    if(window.AMAuth&&AMAuth.configured)AMAuth.api('logout').then(go,go);else go();
  });
})();
