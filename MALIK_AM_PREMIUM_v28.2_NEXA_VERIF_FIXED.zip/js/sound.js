/* Suara via WebAudio — tidak butuh file mp3 */
const AMSound = {
  ctx: null,
  tone(freq, dur, when = 0) {
    try {
      this.ctx = this.ctx || new (window.AudioContext || window.webkitAudioContext)();
      const c = this.ctx, o = c.createOscillator(), g = c.createGain();
      const t = c.currentTime + when;
      o.type = "square"; o.frequency.value = freq;
      g.gain.setValueAtTime(.06, t);
      g.gain.exponentialRampToValueAtTime(.0001, t + dur);
      o.connect(g); g.connect(c.destination);
      o.start(t); o.stop(t + dur);
    } catch (e) {}
  },
  play(name) {
    if (name === "click") this.tone(520, .06);
    if (name === "success") { this.tone(660, .12); this.tone(880, .18, .12); }
    if (name === "error") this.tone(180, .22);
  }
};
document.addEventListener("click", e => {
  if (e.target.closest("button,.btn")) AMSound.play("click");
});
