const api=(action,data)=>fetch('/api/amprem',{
method:'POST',
headers:{'content-type':'application/json'},
body:JSON.stringify({action,...data})
}).then(r=>r.json());

/* ---------- helper tampilan (UI only) ---------- */
const $=id=>document.getElementById(id);
const store={
get(k,d){try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}},
set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
};
const getHistory=()=>{const h=store.get('history',[]);return Array.isArray(h)?h:[]};
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

window.onload=()=>setTimeout(()=>{
splash.classList.add('is-hidden');
setTimeout(()=>splash.style.display='none',300);
},1200);

function load(t,p){
loader.style.display='flex';
loadText.innerText=t;
bar.style.width=p+'%';
}

/* panel status aktivasi: state = idle | working | sent | success | error */
function setStatus(state,text,pct){
$('statusPanel').dataset.state=state;
$('status').innerText=text;
const hero=$('hero');
hero.dataset.state=state;
if(pct!=null){
$('progress').style.width=pct+'%';
$('pct').innerText=pct+'%';
/* playhead timeline di hero ikut progres */
hero.style.setProperty('--p',pct);
hero.dataset.stage=pct>=100?'3':pct>=45?'2':'1';
$('tlTime').textContent='00:'+String(Math.round(pct/10)).padStart(2,'0');
}
}

/* tampilan result box: pesan + order id; JSON mentah disembunyikan di <details> */
function renderResult(r,ok,title){
const msg=(r&&(r.message||(typeof r.error==='string'&&r.error)))||(ok?'Permintaan berhasil diproses.':'Permintaan gagal. Periksa data lalu coba lagi.');
const order=r&&r.orderId?`<div class="kv"><span>Order ID</span><strong>${esc(r.orderId)}</strong><button type="button" class="btn-mini" data-copy="${esc(r.orderId)}">Salin</button></div>`:'';
result.innerHTML=`<div class="res-banner ${ok?'is-ok':'is-fail'}"><span class="res-icon" aria-hidden="true">${ok?'✓':'!'}</span><div><strong>${esc(title)}</strong><small>${esc(msg)}</small></div></div>${order}<details class="raw"><summary>Detail teknis</summary><pre class="code">${esc(JSON.stringify(r,null,2))}</pre></details>`;
}

/* validasi di sisi client sebelum request dikirim */
/* geser layar ke elemen penting (HP: hasil ada di bawah form) */
function goTo(el){
try{
const calm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
el.scrollIntoView({behavior:calm?'auto':'smooth',block:'start'});
}catch(e){}
}
const EMAIL_RE=/^\S+@\S+\.\S+$/;
function invalid(msg){
renderResult({success:false,message:msg},false,'Data belum lengkap');
setStatus('error','Data belum lengkap');
if(window.AMSound)AMSound.play('error');
}

/* ---------- cooldown & lock tombol ---------- */
const COOLDOWN=45; /* detik */
let busySend=false,busyVerify=false,sendTimer=null;
const SEND_LABEL=$('btnSend').textContent,VERIFY_LABEL=$('btnVerify').textContent;
const getUntil=()=>Number(store.get('sendUntil',0))||0;
function updateSendBtn(){
const left=Math.ceil((getUntil()-Date.now())/1000);
const b=$('btnSend');
b.disabled=busySend||left>0;
b.textContent=left>0?'Kirim ulang ('+left+'s)':SEND_LABEL;
if(left>0&&!sendTimer)sendTimer=setInterval(updateSendBtn,1000);
if(left<=0&&sendTimer){clearInterval(sendTimer);sendTimer=null;}
}
function setVerifyBusy(v){busyVerify=v;const b=$('btnVerify');b.disabled=v;b.textContent=v?'Memproses…':VERIFY_LABEL;}

/* jaringan gagal / respons bukan JSON: tutup modal & tampilkan error */
function fail(){
loader.style.display='none';
renderResult({success:false,message:'Tidak bisa terhubung ke server. Coba lagi.'},false,'Koneksi gagal');
setStatus('error','Koneksi gagal');
if(window.AMSound)AMSound.play('error');
}

/* ---------- alur aktivasi (logic asli) ---------- */
function sendLink(){
if(busySend||getUntil()>Date.now())return;
const em=email.value.trim();
if(!EMAIL_RE.test(em))return invalid('Masukkan email Alight Motion yang valid.');
busySend=true;updateSendBtn();
load('Mengirim magic link…',40);
setStatus('working','Mengirim magic link',40);
api('send',{email:em}).then(r=>{
loader.style.display='none';
const ok=!(r&&(r.success===false||r.error));
if(ok)store.set('sendUntil',Date.now()+COOLDOWN*1000);
renderResult(r,ok,ok?'Magic link terkirim':'Permintaan gagal');
setStatus(ok?'sent':'error',ok?'Magic link terkirim':'Permintaan gagal',ok?50:null);
goTo(ok?$('btnVerify').closest('.card'):$('statusPanel'));
}).catch(fail).finally(()=>{busySend=false;updateSendBtn();});
}

function verify(){
if(busyVerify)return;
const em=email.value.trim(),lk=link.value.trim();
if(!EMAIL_RE.test(em))return invalid('Masukkan email Alight Motion yang valid.');
if(!lk)return invalid('Paste link verifikasi dari email dulu.');
setVerifyBusy(true);
load('Memverifikasi akun…',70);
setStatus('working','Memverifikasi akun',70);
api('verify',{email:em,rawLink:lk}).then(r=>{
bar.style.width='100%';
loader.style.display='none';
renderResult(r,!!r.success,r.success?'Premium aktif':'Verifikasi gagal');
setStatus(r.success?'success':'error',r.success?'Premium aktif':'Verifikasi gagal',r.success?100:null);
if(r.success){
$('premiumDashboard').style.display='block';
const device = /Android/i.test(navigator.userAgent)?'Android':(/iPhone|iPad/i.test(navigator.userAgent)?'iOS':'Desktop');
if($('deviceInfo')) $('deviceInfo').textContent=device;
if($('activeDate')) $('activeDate').textContent=new Date().toLocaleDateString('id-ID');
if($('dashEmail')) $('dashEmail').textContent=em;
popup.style.display='block';
const ss=$('successScreen'); if(ss) ss.style.display='block'; const se=$('successEmail'); if(se) se.textContent=em;
setTimeout(()=>popup.style.display='none',4000);
const h=getHistory();
h.unshift({email:em,order:r.orderId});
store.set('history',h.slice(0,50));
if(window.AMSound)AMSound.play('success');
showHistory();
}else if(window.AMSound)AMSound.play('error');
goTo($('statusPanel'));
}).catch(fail).finally(()=>setVerifyBusy(false));
}

/* NOTE: pakai getElementById karena `history` di JS = window.history,
   bukan elemen #history, sehingga history.innerHTML tidak menulis ke halaman. */
function showHistory(){
const h=getHistory();
$('history').innerHTML=h.length?h.map(x=>`<div class="hist-item"><div class="hist-email">${esc(x.email)}</div><span class="badge badge-sm">Aktif</span><div class="hist-order"><span>Order ID</span><code>${esc(x.order||'—')}</code>${x.order?`<button type="button" class="btn-mini" data-copy="${esc(x.order)}">Salin</button>`:''}</div></div>`).join('')+`<button type="button" class="btn-mini btn-mini-danger" data-clear="1">Hapus riwayat</button>`:`<div class="empty"><span class="empty-icon" aria-hidden="true">—</span><strong>Belum ada riwayat.</strong><small>Order yang berhasil akan muncul di sini.</small></div>`;
}
showHistory();


/* ---------- copy / paste / hapus riwayat ---------- */
function copyText(t){
if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(t);
return new Promise((ok,no)=>{
const ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';
document.body.appendChild(ta);ta.select();
try{document.execCommand('copy')?ok():no()}catch(e){no()}
ta.remove();
});
}
function flash(btn,text,ms){
const old=btn.dataset.label||btn.textContent;btn.dataset.label=old;
btn.textContent=text;clearTimeout(btn._t);
btn._t=setTimeout(()=>{btn.textContent=old;},ms||1500);
}
document.addEventListener('click',e=>{
const c=e.target.closest('[data-copy]');
if(c){copyText(c.dataset.copy).then(()=>flash(c,'Tersalin ✓')).catch(()=>flash(c,'Gagal menyalin'));return;}
if(e.target.closest('[data-clear]')){
if(confirm('Hapus semua riwayat order di perangkat ini?')){store.set('history',[]);showHistory();}
}
});
$('btnPaste').addEventListener('click',()=>{
const b=$('btnPaste');
if(!navigator.clipboard||!navigator.clipboard.readText){link.focus();return flash(b,'Tempel manual (tahan layar)',2200);}
navigator.clipboard.readText().then(t=>{
if(t&&t.trim()){link.value=t.trim();flash(b,'Tertempel ✓');}else flash(b,'Clipboard kosong');
}).catch(()=>{link.focus();flash(b,'Izin ditolak, tempel manual',2200);});
});

/* ---------- status server nyata ---------- */
function setServer(state,text){
const b=$('srvBadge');b.classList.remove('is-check','is-off');
if(state!=='on')b.classList.add(state==='off'?'is-off':'is-check');
$('srvText').textContent=text;
}
function checkServer(){
const ctrl=new AbortController();
const t=setTimeout(()=>ctrl.abort(),7000);
fetch('/api/health',{signal:ctrl.signal,cache:'no-store'})
.then(r=>r.json())
.then(d=>d&&d.online?setServer('on','Server online'):setServer('off','Server offline'))
.catch(()=>setServer('off','Server offline'))
.finally(()=>clearTimeout(t));
}
checkServer();
setInterval(()=>{if(!document.hidden)checkServer();},60000);
updateSendBtn();

// Premium Experience V5 navigation polish
(function(){
 document.querySelectorAll('.premium-nav a').forEach(a=>{
  a.addEventListener('click',()=>{
   document.body.classList.add('page-transition');
   setTimeout(()=>document.body.classList.remove('page-transition'),400);
  });
 });
})();

// Premium Experience V6: prevent double tap glitches and add ready class
document.addEventListener('DOMContentLoaded',()=>{
 document.body.classList.add('premium-ready');
 document.querySelectorAll('button').forEach(btn=>{
  btn.addEventListener('click',()=>{
   btn.classList.add('clicked');
   setTimeout(()=>btn.classList.remove('clicked'),180);
  });
 });
});
